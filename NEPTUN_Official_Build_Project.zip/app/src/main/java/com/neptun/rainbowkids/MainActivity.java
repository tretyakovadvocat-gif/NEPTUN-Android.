package com.neptun.rainbowkids;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

/**
 * Offline Android shell for the original local HTML5 Canvas game.
 * Does not transmit user data or access a network.
 */
public final class MainActivity extends Activity {
    private WebView gameView;
    private static final String GAME_URL =
            "https://appassets.androidplatform.net/assets/index.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        immersive();

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        gameView = new WebView(this);
        gameView.setBackgroundColor(0xffa0ecf4);
        WebSettings s = gameView.getSettings();
        s.setJavaScriptEnabled(true); // HTML5 game logic
        s.setDomStorageEnabled(true); // level progress in localStorage
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        gameView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        gameView.setWebChromeClient(new WebChromeClient());
        gameView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(
                    WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().equals(GAME_URL);
            }
        });
        setContentView(gameView);
        gameView.loadUrl(GAME_URL);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // WebView/Canvas receives resize and orientation events itself.
    }

    @Override public void onPause() {
        if (gameView != null) {
            gameView.evaluateJavascript("if(document.getElementById('hud').style.display==='block')document.getElementById('pauseGame').click()", null);
            gameView.onPause();
        }
        super.onPause();
    }

    @Override public void onResume() {
        super.onResume();
        if (gameView != null) gameView.onResume();
    }

    @Override public void onBackPressed() {
        if (gameView == null) { super.onBackPressed(); return; }
        // Mirrors the browser Escape key: pause / resume / back to home.
        gameView.evaluateJavascript(
            "(function(){" +
            "if(!document.getElementById('menu').hidden)return 'home';" +
            "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));" +
            "return 'handled';" +
            "})()",
            result -> { if ("\"home\"".equals(result)) finish(); }
        );
    }

    @Override protected void onDestroy() {
        if (gameView != null) {
            gameView.destroy();
            gameView = null;
        }
        super.onDestroy();
    }
}
